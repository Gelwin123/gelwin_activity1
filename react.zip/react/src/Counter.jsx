import React from "react";
import "./Counter.css";

function Counter({ count }) {
  return (
    <div className="counter-box">
      <p className="count-value">{count}</p>
    </div>
  );
}

export default Counter;
