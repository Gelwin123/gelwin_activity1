import { useState } from "react";
import "./App.css";
import FinalBox from "./FinalBox"; // Import FinalBox component

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
     

      {/* Wrap everything inside FinalBox */}
      <FinalBox count={count} setCount={setCount} />
    </>
  );
}

export default App;
