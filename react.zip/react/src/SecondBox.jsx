import "./SecondBox.css";

function SecondBox({ setCount }) {
  return (
    <div className="second-box">
      <button onClick={() => setCount((count) => count + 1)}>+</button>
      <button onClick={() => setCount((prev) => prev - 1)}>-</button>
    </div>
  );
}

export default SecondBox;
