import "./FinalBox.css";
import Counter from "./Counter"; 
import LastBox from "./LastBox";

function FinalBox({ count, setCount }) {
  return (
    <div className="final-box">
      {/* Counter box displaying the count */}
      <Counter count={count} />

      {/* Last box should receive count */}
      <LastBox count={count} setCount={setCount} />
    </div>
  );
}

export default FinalBox;
