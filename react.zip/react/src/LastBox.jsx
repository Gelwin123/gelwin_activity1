import "./LastBox.css";
import SecondBox from "./SecondBox"; // Import SecondBox component
import "./App.css";

function LastBox({ count, setCount }) {
  return (
    <div className="last-box">
      {/* Display current value */}
      <p className="current-value">The current value is {count}</p>

      {/* Second box with buttons */}
      <SecondBox setCount={setCount} />
    </div>
  );
}

export default LastBox;
